# AdBlocker
An Ad Blocker with some simple lines of code.
